package com.example.auth_service.service;

import com.example.auth_service.model.User;
import com.example.auth_service.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;

import javax.crypto.SecretKey;

@Service
@Slf4j
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder(12);

    // In production, load from environment variable or Vault — never hardcode
    private static final String JWT_SECRET = "nsip-platform-secret-key-must-be-at-least-256-bits-long-for-hs256";
    private static final long JWT_EXPIRY_MS = 24 * 60 * 60 * 1000; // 24 hours

    /**
     * Register a new user with BCrypt-hashed password.
     * BCrypt with strength 12 means ~250ms per hash — fast enough for UX, slow enough to resist brute-force.
     */
    public User register(String nationalId, String fullName, String email, String rawPassword, User.Role role) {
        if (userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException("Email already registered.");
        }
        if (userRepository.existsByNationalId(nationalId)) {
            throw new IllegalArgumentException("National ID already registered.");
        }

        User user = new User();
        user.setNationalId(nationalId);
        user.setFullName(fullName);
        user.setEmail(email);
        user.setPasswordHash(passwordEncoder.encode(rawPassword)); // BCrypt hash with salt
        user.setRole(role);

        User saved = userRepository.save(user);
        log.info("Registered user: {} with role: {}", saved.getEmail(), saved.getRole());
        return saved;
    }

    /**
     * Authenticate user and return a signed JWT token with role claims.
     */
    public String login(String email, String password) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("Invalid credentials."));

        // BCrypt comparison — timing-safe, handles salt automatically
        if (!passwordEncoder.matches(password, user.getPasswordHash())) {
            throw new IllegalArgumentException("Invalid credentials.");
        }

        // Generate a real, signed JWT with claims
        SecretKey key = Keys.hmacShaKeyFor(JWT_SECRET.getBytes(StandardCharsets.UTF_8));
        String jwt = Jwts.builder()
                .subject(user.getId().toString())
                .claim("role", user.getRole().name())
                .claim("email", user.getEmail())
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + JWT_EXPIRY_MS))
                .signWith(key)
                .compact();

        log.info("User {} logged in successfully. Role: {}", email, user.getRole());
        return jwt;
    }

    /**
     * Validate a JWT token and extract the user ID.
     * Throws if the token is expired, tampered, or malformed.
     */
    public UUID validateToken(String token) {
        SecretKey key = Keys.hmacShaKeyFor(JWT_SECRET.getBytes(StandardCharsets.UTF_8));
        String userId = Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload()
                .getSubject();
        return UUID.fromString(userId);
    }

    /**
     * Extract the role from a validated JWT token.
     */
    public String extractRole(String token) {
        SecretKey key = Keys.hmacShaKeyFor(JWT_SECRET.getBytes(StandardCharsets.UTF_8));
        return Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload()
                .get("role", String.class);
    }

    public Optional<User> findById(UUID id) {
        return userRepository.findById(id);
    }
}
