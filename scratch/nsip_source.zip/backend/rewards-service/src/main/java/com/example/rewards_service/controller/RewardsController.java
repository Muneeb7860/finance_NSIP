package com.example.rewards_service.controller;

import com.example.rewards_service.service.RewardsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/rewards")
public class RewardsController {

    @Autowired
    private RewardsService rewardsService;

    @GetMapping("/balance/{userId}")
    public ResponseEntity<?> getBalance(@PathVariable UUID userId) {
        return ResponseEntity.ok(Map.of("userId", userId, "balance", rewardsService.getBalance(userId)));
    }

    @PostMapping("/award")
    public ResponseEntity<?> awardPoints(@RequestBody Map<String, String> body) {
        return ResponseEntity.ok(rewardsService.awardPoints(
                UUID.fromString(body.get("userId")),
                Integer.parseInt(body.get("points")),
                body.get("description")
        ));
    }

    @PostMapping("/sessions/book")
    public ResponseEntity<?> bookSession(@RequestBody Map<String, String> body) {
        try {
            return ResponseEntity.ok(rewardsService.bookSession(
                    UUID.fromString(body.get("userId")),
                    UUID.fromString(body.get("advisorId")),
                    LocalDateTime.parse(body.get("scheduledTime"))
            ));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PatchMapping("/sessions/{sessionId}/cancel")
    public ResponseEntity<?> cancelSession(@PathVariable UUID sessionId) {
        return ResponseEntity.ok(rewardsService.cancelSession(sessionId));
    }

    @PatchMapping("/sessions/{sessionId}/reschedule")
    public ResponseEntity<?> rescheduleSession(@PathVariable UUID sessionId, @RequestParam String newTime) {
        return ResponseEntity.ok(rewardsService.rescheduleSession(sessionId, LocalDateTime.parse(newTime)));
    }
}
