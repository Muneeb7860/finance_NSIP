package com.example.claim_service.service;

import com.example.claim_service.model.Claim;
import com.example.claim_service.repository.ClaimRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
@Slf4j
public class ClaimService {

    @Autowired
    private ClaimRepository claimRepository;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    // Credit limits based on total savings (would come from ContributionService in production)
    private static final BigDecimal TOTAL_SAVINGS = new BigDecimal("150000");
    private static final BigDecimal PERSONAL_LIMIT = TOTAL_SAVINGS.multiply(new BigDecimal("0.30")); // 45,000
    private static final BigDecimal EMERGENCY_LIMIT = TOTAL_SAVINGS.multiply(new BigDecimal("0.70")); // 105,000

    /**
     * Submit a new insurance claim with loan amount validation.
     *
     * FLAW #10 FIX: Validates the requested loan amount against the 30% / 70% credit limits
     * BEFORE creating the claim or triggering the Saga.
     */
    @Transactional
    public Claim submitClaim(UUID userId, Claim.ClaimType type, BigDecimal amount, String description) {
        // Input validation
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Claim amount must be positive.");
        }

        // Loan amount validation against credit limits
        if (type == Claim.ClaimType.PERSONAL_LOAN && amount.compareTo(PERSONAL_LIMIT) > 0) {
            throw new IllegalArgumentException(
                    "Personal loan amount exceeds your 30% credit limit of SAR " + PERSONAL_LIMIT + ".");
        }
        if (type == Claim.ClaimType.EMERGENCY_RELIEF && amount.compareTo(EMERGENCY_LIMIT) > 0) {
            throw new IllegalArgumentException(
                    "Emergency relief amount exceeds your 70% credit limit of SAR " + EMERGENCY_LIMIT + ".");
        }

        Claim claim = new Claim();
        claim.setUserId(userId);
        claim.setClaimType(type);
        claim.setAmount(amount);
        claim.setDescription(description);
        claim.setStatus(Claim.ClaimStatus.PENDING);

        Claim saved = claimRepository.save(claim);
        log.info("Claim submitted: {} type={} amount={}", saved.getId(), type, amount);

        // If it's a loan type, kick off the Saga
        if (type == Claim.ClaimType.PERSONAL_LOAN || type == Claim.ClaimType.EMERGENCY_RELIEF) {
            String payload = String.format("{\"claimId\":\"%s\", \"userId\":\"%s\", \"amount\":%s, \"type\":\"%s\"}",
                    saved.getId(), userId, amount, type);
            kafkaTemplate.send("loan.requested", payload);
            log.info("Loan Saga initiated for claim: {}", saved.getId());
        }

        return saved;
    }

    /**
     * Admin approves a claim manually.
     */
    @Transactional
    public Claim approveClaim(UUID claimId) {
        Claim claim = claimRepository.findById(claimId)
                .orElseThrow(() -> new IllegalArgumentException("Claim not found."));
        claim.setStatus(Claim.ClaimStatus.APPROVED);
        claim.setUpdatedAt(LocalDateTime.now());
        return claimRepository.save(claim);
    }

    /**
     * Admin rejects a claim.
     */
    @Transactional
    public Claim rejectClaim(UUID claimId) {
        Claim claim = claimRepository.findById(claimId)
                .orElseThrow(() -> new IllegalArgumentException("Claim not found."));
        claim.setStatus(Claim.ClaimStatus.REJECTED);
        claim.setUpdatedAt(LocalDateTime.now());
        return claimRepository.save(claim);
    }

    public List<Claim> getClaimsByUser(UUID userId) {
        return claimRepository.findByUserId(userId);
    }

    public List<Claim> getPendingClaims() {
        return claimRepository.findByStatus(Claim.ClaimStatus.PENDING);
    }

    // --- Kafka Listeners for Saga Orchestrator commands ---

    @KafkaListener(topics = "claim.command.complete", groupId = "claim-group")
    @Transactional
    public void handleSagaComplete(String payload) {
        log.info("Saga completed. Marking claim as DISBURSED. Payload: {}", payload);
        // In production, parse the claimId from payload and update the claim status
    }

    @KafkaListener(topics = "claim.command.fail", groupId = "claim-group")
    @Transactional
    public void handleSagaFail(String payload) {
        log.warn("Saga failed. Marking claim as FAILED. Payload: {}", payload);
        // In production, parse the claimId from payload and update the claim status
    }
}
