package com.example.claim_service.controller;

import com.example.claim_service.model.Claim;
import com.example.claim_service.service.ClaimService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/claims")
public class ClaimController {

    @Autowired
    private ClaimService claimService;

    /**
     * Submit a claim — any authenticated user (CUSTOMER role).
     */
    @PostMapping
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<?> submitClaim(@RequestBody Map<String, String> body) {
        Claim claim = claimService.submitClaim(
                UUID.fromString(body.get("userId")),
                Claim.ClaimType.valueOf(body.get("claimType")),
                new BigDecimal(body.get("amount")),
                body.get("description")
        );
        return ResponseEntity.ok(claim);
    }

    /**
     * View own claims — any authenticated user.
     */
    @GetMapping("/user/{userId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> getUserClaims(@PathVariable UUID userId) {
        return ResponseEntity.ok(claimService.getClaimsByUser(userId));
    }

    /**
     * View pending claims queue — ADMIN only (Back Office).
     */
    @GetMapping("/pending")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> getPendingClaims() {
        return ResponseEntity.ok(claimService.getPendingClaims());
    }

    /**
     * Approve a claim — ADMIN only (Back Office).
     */
    @PatchMapping("/{claimId}/approve")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> approveClaim(@PathVariable UUID claimId) {
        return ResponseEntity.ok(claimService.approveClaim(claimId));
    }

    /**
     * Reject a claim — ADMIN only (Back Office).
     */
    @PatchMapping("/{claimId}/reject")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> rejectClaim(@PathVariable UUID claimId) {
        return ResponseEntity.ok(claimService.rejectClaim(claimId));
    }
}
