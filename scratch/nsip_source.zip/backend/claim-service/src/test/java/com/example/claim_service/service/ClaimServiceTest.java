package com.example.claim_service.service;

import com.example.claim_service.model.Claim;
import com.example.claim_service.repository.ClaimRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;

import java.math.BigDecimal;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ClaimServiceTest {

    @Mock
    private ClaimRepository claimRepository;

    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;

    @InjectMocks
    private ClaimService claimService;

    private UUID userId;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
    }

    @Test
    @DisplayName("Valid personal loan within 30% limit should succeed")
    void testValidPersonalLoan() {
        when(claimRepository.save(any(Claim.class))).thenAnswer(i -> {
            Claim c = i.getArgument(0);
            c.setId(UUID.randomUUID());
            return c;
        });

        Claim result = claimService.submitClaim(userId, Claim.ClaimType.PERSONAL_LOAN,
                new BigDecimal("40000"), "Need funds for education");

        assertNotNull(result);
        assertEquals(Claim.ClaimStatus.PENDING, result.getStatus());
        verify(kafkaTemplate).send(eq("loan.requested"), anyString());
    }

    @Test
    @DisplayName("Personal loan exceeding 30% limit (SAR 45,000) should be rejected")
    void testPersonalLoanExceedsLimit() {
        assertThrows(IllegalArgumentException.class, () ->
                claimService.submitClaim(userId, Claim.ClaimType.PERSONAL_LOAN,
                        new BigDecimal("50000"), "Too much"));
    }

    @Test
    @DisplayName("Emergency relief exceeding 70% limit (SAR 105,000) should be rejected")
    void testEmergencyReliefExceedsLimit() {
        assertThrows(IllegalArgumentException.class, () ->
                claimService.submitClaim(userId, Claim.ClaimType.EMERGENCY_RELIEF,
                        new BigDecimal("110000"), "Emergency"));
    }

    @Test
    @DisplayName("Negative claim amount should be rejected")
    void testNegativeAmount() {
        assertThrows(IllegalArgumentException.class, () ->
                claimService.submitClaim(userId, Claim.ClaimType.MEDICAL,
                        new BigDecimal("-500"), "Invalid"));
    }

    @Test
    @DisplayName("Zero claim amount should be rejected")
    void testZeroAmount() {
        assertThrows(IllegalArgumentException.class, () ->
                claimService.submitClaim(userId, Claim.ClaimType.MEDICAL,
                        BigDecimal.ZERO, "Zero"));
    }

    @Test
    @DisplayName("Non-loan claim type should NOT trigger Saga")
    void testMedicalClaimDoesNotTriggerSaga() {
        when(claimRepository.save(any(Claim.class))).thenAnswer(i -> {
            Claim c = i.getArgument(0);
            c.setId(UUID.randomUUID());
            return c;
        });

        claimService.submitClaim(userId, Claim.ClaimType.MEDICAL,
                new BigDecimal("5000"), "Hospital visit");

        verify(kafkaTemplate, never()).send(eq("loan.requested"), anyString());
    }

    @Test
    @DisplayName("Personal loan at exactly SAR 45,000 (boundary) should succeed")
    void testPersonalLoanExactBoundary() {
        when(claimRepository.save(any(Claim.class))).thenAnswer(i -> {
            Claim c = i.getArgument(0);
            c.setId(UUID.randomUUID());
            return c;
        });

        Claim result = claimService.submitClaim(userId, Claim.ClaimType.PERSONAL_LOAN,
                new BigDecimal("45000"), "Exact limit");

        assertNotNull(result);
        assertEquals(Claim.ClaimStatus.PENDING, result.getStatus());
    }
}
