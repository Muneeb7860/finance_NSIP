package com.example.education_service.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;
import java.util.UUID;

/**
 * Tracks daily learning streaks per user.
 * A streak breaks if the user misses a calendar day without completing any learning activity.
 */
@Entity
@Table(name = "learning_streaks")
@Data
public class LearningStreak {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false, unique = true)
    private UUID userId;

    @Column(nullable = false)
    private int currentStreak = 0;

    @Column(nullable = false)
    private int longestStreak = 0;

    @Column(nullable = false)
    private LocalDate lastActivityDate;

    /** Bonus points awarded per streak milestone (7-day, 30-day, etc.) */
    public int getStreakBonusPoints() {
        if (currentStreak >= 30) return 500;
        if (currentStreak >= 14) return 200;
        if (currentStreak >= 7) return 100;
        return 0;
    }
}
