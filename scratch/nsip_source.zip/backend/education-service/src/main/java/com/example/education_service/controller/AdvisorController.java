package com.example.education_service.controller;

import com.example.education_service.service.AdvisorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/advisors")
@Tag(name = "Financial Advisors", description = "Advisor self-service, booking, cancellation, and reviews")
public class AdvisorController {

    @Autowired private AdvisorService advisorService;

    // --- ADVISOR SELF-SERVICE ---

    @Operation(summary = "Register as a financial advisor")
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String, String> body) {
        try {
            return ResponseEntity.ok(advisorService.registerAdvisor(
                    UUID.fromString(body.get("userId")),
                    body.get("name"), body.get("specialty"), body.get("bio")));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @Operation(summary = "Advisor views their schedule")
    @GetMapping("/{advisorId}/schedule")
    public ResponseEntity<?> getSchedule(@PathVariable UUID advisorId) {
        return ResponseEntity.ok(advisorService.getMySchedule(advisorId));
    }

    @Operation(summary = "Advisor views their ratings and reviews")
    @GetMapping("/{advisorId}/ratings")
    public ResponseEntity<?> getRatings(@PathVariable UUID advisorId) {
        return ResponseEntity.ok(advisorService.getMyRatings(advisorId));
    }

    @Operation(summary = "Advisor cancels a session (points restored to customer)")
    @PatchMapping("/sessions/{sessionId}/advisor-cancel")
    public ResponseEntity<?> advisorCancel(@PathVariable UUID sessionId, @RequestBody Map<String, String> body) {
        try {
            return ResponseEntity.ok(advisorService.advisorCancelSession(sessionId, body.get("reason")));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @Operation(summary = "Reschedule a session")
    @PatchMapping("/sessions/{sessionId}/reschedule")
    public ResponseEntity<?> reschedule(@PathVariable UUID sessionId, @RequestBody Map<String, String> body) {
        try {
            return ResponseEntity.ok(advisorService.rescheduleSession(sessionId, LocalDateTime.parse(body.get("newTime"))));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // --- CUSTOMER ENDPOINTS ---

    @Operation(summary = "Browse all available advisors")
    @GetMapping
    public ResponseEntity<?> browseAdvisors() {
        return ResponseEntity.ok(advisorService.getActiveAdvisors());
    }

    @Operation(summary = "Book a session (deducts points)")
    @PostMapping("/sessions/book")
    public ResponseEntity<?> book(@RequestBody Map<String, String> body) {
        try {
            return ResponseEntity.ok(advisorService.bookSession(
                    UUID.fromString(body.get("customerId")),
                    UUID.fromString(body.get("advisorId")),
                    LocalDateTime.parse(body.get("scheduledAt"))));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @Operation(summary = "Customer cancels a session (points restored)")
    @PatchMapping("/sessions/{sessionId}/customer-cancel")
    public ResponseEntity<?> customerCancel(@PathVariable UUID sessionId, @RequestBody Map<String, String> body) {
        try {
            return ResponseEntity.ok(advisorService.customerCancelSession(sessionId, body.get("reason")));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @Operation(summary = "Submit a review for a completed session")
    @PostMapping("/sessions/{sessionId}/review")
    public ResponseEntity<?> review(@PathVariable UUID sessionId, @RequestBody Map<String, String> body) {
        try {
            return ResponseEntity.ok(advisorService.submitReview(
                    sessionId,
                    UUID.fromString(body.get("customerId")),
                    Integer.parseInt(body.get("rating")),
                    body.get("comment")));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @Operation(summary = "Get customer's session history")
    @GetMapping("/sessions/customer/{customerId}")
    public ResponseEntity<?> customerSessions(@PathVariable UUID customerId) {
        return ResponseEntity.ok(advisorService.getCustomerSessions(customerId));
    }
}
