import { useState } from 'react';
import { BrowserRouter, Routes, Route, NavLink, Navigate, useNavigate } from 'react-router-dom';
import { api } from './api';
import './index.css';

// =============================================================================
// Reusable Components
// =============================================================================

function LoadingSpinner() {
  return <div style={{ display: 'flex', justifyContent: 'center', padding: '3rem' }}>
    <div style={{ width: '40px', height: '40px', border: '3px solid var(--neo-border)', borderTopColor: 'var(--neo-stripe-purple)', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
  </div>;
}

function ErrorBanner({ message, onDismiss }: { message: string; onDismiss: () => void }) {
  return <div style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid var(--neo-danger)', borderRadius: '12px', padding: '16px', marginBottom: '24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
    <span style={{ color: 'var(--neo-danger)' }}>⚠️ {message}</span>
    <button onClick={onDismiss} style={{ background: 'none', border: 'none', color: 'var(--neo-text-muted)', cursor: 'pointer', fontSize: '1.2rem' }}>✕</button>
  </div>;
}

// =============================================================================
// Role Selector (Landing Page)
// =============================================================================
function RoleSelector() {
  const navigate = useNavigate();
  return (
    <div className="neo-app" style={{ alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '2rem' }}>
      <div className="neo-brand" style={{ fontSize: '3rem' }}>NSIP Platform</div>
      <h2 style={{ color: 'var(--neo-text-muted)', fontWeight: 400 }}>Select your portal access level:</h2>
      <div style={{ display: 'flex', gap: '2rem' }}>
        <button className="neo-card" style={{ width: '250px', cursor: 'pointer', textAlign: 'center' }} onClick={() => navigate('/customer/portfolio')}>
          <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>👤</div>
          <h3>Customer / Contributor</h3>
          <p style={{ color: 'var(--neo-text-muted)', fontSize: '0.9rem', marginTop: '1rem' }}>Manage personal portfolio, loans, and planning.</p>
        </button>
        <button className="neo-card" style={{ width: '250px', cursor: 'pointer', textAlign: 'center' }} onClick={() => navigate('/employer')}>
          <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🏢</div>
          <h3>Business Owner</h3>
          <p style={{ color: 'var(--neo-text-muted)', fontSize: '0.9rem', marginTop: '1rem' }}>Manage payroll and employee contributions.</p>
        </button>
        <button className="neo-card" style={{ width: '250px', cursor: 'pointer', textAlign: 'center', border: '1px solid var(--neo-stripe-purple)' }} onClick={() => navigate('/admin')}>
          <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🛡️</div>
          <h3 style={{ color: 'var(--neo-stripe-purple)' }}>Back Office Admin</h3>
          <p style={{ color: 'var(--neo-text-muted)', fontSize: '0.9rem', marginTop: '1rem' }}>Manage platform approvals and saga metrics.</p>
        </button>
      </div>
    </div>
  );
}

// =============================================================================
// Customer Portal
// =============================================================================
function CustomerPortal() {
  return (
    <div className="neo-app">
      <aside className="neo-sidebar">
        <div className="neo-brand"><span>NSIP</span><span style={{ color: 'var(--neo-text-muted)', fontSize: '1rem' }}>Wealth</span></div>
        <nav className="neo-nav">
          <NavLink to="/customer/portfolio" className={({ isActive }) => `neo-nav-item ${isActive ? 'active' : ''}`}>📊 Portfolio & Loans</NavLink>
          <NavLink to="/customer/learning" className={({ isActive }) => `neo-nav-item ${isActive ? 'active' : ''}`}>🎓 Learning</NavLink>
          <NavLink to="/customer/wallet" className={({ isActive }) => `neo-nav-item ${isActive ? 'active' : ''}`}>💳 Digital Wallet</NavLink>
          <NavLink to="/customer/wellness" className={({ isActive }) => `neo-nav-item ${isActive ? 'active' : ''}`}>🏃 Wellness</NavLink>
          <NavLink to="/customer/planning" className={({ isActive }) => `neo-nav-item ${isActive ? 'active' : ''}`}>📈 Financial Planning</NavLink>
          <NavLink to="/customer/help" className={({ isActive }) => `neo-nav-item ${isActive ? 'active' : ''}`}>💬 Help Centre</NavLink>
        </nav>
        <div style={{ marginTop: 'auto' }}>
          <NavLink to="/" className="neo-btn outline" style={{ textDecoration: 'none', display: 'block', textAlign: 'center' }}>Log Out</NavLink>
        </div>
      </aside>
      <main className="neo-main">
        <Routes>
          <Route path="portfolio" element={<PortfolioPage />} />
          <Route path="learning" element={<LearningPage />} />
          <Route path="wallet" element={<WalletPage />} />
          <Route path="wellness" element={<WellnessPage />} />
          <Route path="planning" element={<PlanningPage />} />
          <Route path="help" element={<HelpCentrePage />} />
          <Route path="*" element={<Navigate to="portfolio" />} />
        </Routes>
      </main>
    </div>
  );
}

// --- Portfolio Page ---
function PortfolioPage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loanAmount, setLoanAmount] = useState('');
  const [loanDescription, setLoanDescription] = useState('');

  const handleApplyLoan = async () => {
    if (!loanAmount || isNaN(Number(loanAmount)) || Number(loanAmount) <= 0) {
      setError('Please enter a valid positive loan amount.');
      return;
    }
    if (Number(loanAmount) > 45000) {
      setError('Personal loan cannot exceed SAR 45,000 (30% of your savings).');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      await api.submitClaim('mock-user-id', 'PERSONAL_LOAN', loanAmount, loanDescription || 'Personal loan request');
      setLoanAmount('');
      setLoanDescription('');
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <header className="neo-header">
        <div>
          <div style={{ color: 'var(--neo-text-muted)', marginBottom: '8px', fontWeight: '500' }}>Total Portfolio Balance</div>
          <div className="neo-balance">SAR 150,000<span style={{ fontSize: '1.5rem', color: 'var(--neo-text-muted)' }}>.00</span></div>
        </div>
        <div><div className="neo-badge success">Vested (+3 Years)</div></div>
      </header>

      {error && <ErrorBanner message={error} onDismiss={() => setError(null)} />}

      <div className="neo-grid">
        <div className="neo-card">
          <div className="neo-card-label">Personal Loan Credit (30%)</div>
          <div className="neo-card-value">SAR 45,000</div>
          <div style={{ marginTop: '16px' }}>
            <input type="number" placeholder="Loan amount (SAR)" value={loanAmount} onChange={e => setLoanAmount(e.target.value)} min="1" max="45000" style={{ width: '100%', padding: '10px', borderRadius: '8px', border: '1px solid var(--neo-border)', background: 'var(--neo-bg)', color: 'var(--neo-text)', marginBottom: '8px', boxSizing: 'border-box' }} />
            <input type="text" placeholder="Description (optional)" value={loanDescription} onChange={e => setLoanDescription(e.target.value)} style={{ width: '100%', padding: '10px', borderRadius: '8px', border: '1px solid var(--neo-border)', background: 'var(--neo-bg)', color: 'var(--neo-text)', marginBottom: '12px', boxSizing: 'border-box' }} />
            <button className="neo-btn" onClick={handleApplyLoan} disabled={loading} style={{ width: '100%', opacity: loading ? 0.6 : 1 }}>
              {loading ? 'Processing...' : 'Apply for Personal Loan'}
            </button>
          </div>
        </div>
        <div className="neo-card">
          <div className="neo-card-label">Emergency Fund (70%)</div>
          <div className="neo-card-value" style={{ color: 'var(--neo-danger)' }}>SAR 105,000</div>
          <div style={{ marginTop: '24px' }}><button className="neo-btn outline" style={{ borderColor: 'var(--neo-danger)', color: 'var(--neo-danger)' }}>Request Emergency Relief</button></div>
        </div>
      </div>

      <h3 style={{ marginBottom: '24px' }}>Payment Gateway Integrations</h3>
      <div className="neo-card">
        <div style={{ display: 'flex', gap: '24px' }}>
          <div style={{ flex: 1 }}>
            <div className="neo-card-label">Top up / Auto-Debit via Stripe</div>
            <button className="neo-btn stripe">Connect Stripe Payment</button>
          </div>
          <div style={{ flex: 1, borderLeft: '1px solid var(--neo-border)', paddingLeft: '24px' }}>
            <div className="neo-card-label">Local Wallets (PhonePe / Paytm)</div>
            <button className="neo-btn outline">Add Local Wallet</button>
          </div>
        </div>
      </div>
    </>
  );
}

// --- Learning Page (Gamification + LMS + Quiz + Streak + Certificates + Session Booking) ---
function LearningPage() {
  const [tab, setTab] = useState<'dashboard'|'courses'|'session'>('dashboard');
  const [quizActive, setQuizActive] = useState(false);
  const [quizScore, setQuizScore] = useState(0);
  const streak = 12; const points = 1420; const certs = 3;
  const activeDaysThisWeek = 3; const weeklyStreak = 3; const monthlyStreaks = 2;

  const courses = [
    { id: '1', title: 'Insurance 101', category: 'INSURANCE', difficulty: 'Beginner', duration: 15, points: 50, progress: 100, videoUrl: '#' },
    { id: '2', title: 'Smart Budgeting', category: 'BUDGETING', difficulty: 'Beginner', duration: 20, points: 75, progress: 60, videoUrl: '#' },
    { id: '3', title: 'Investment Fundamentals', category: 'INVESTMENT', difficulty: 'Intermediate', duration: 30, points: 100, progress: 0, videoUrl: '#' },
    { id: '4', title: 'Tax Planning Mastery', category: 'TAX', difficulty: 'Advanced', duration: 45, points: 150, progress: 0, videoUrl: '#' },
    { id: '5', title: 'Retirement Blueprint', category: 'RETIREMENT', difficulty: 'Intermediate', duration: 25, points: 100, progress: 30, videoUrl: '#' },
  ];

  const myCerts = [
    { name: 'Insurance 101', number: 'NSIP-CERT-2026-00001', score: 95, date: '2026-04-10' },
    { name: 'Financial Literacy', number: 'NSIP-CERT-2026-00008', score: 92, date: '2026-03-22' },
    { name: 'Emergency Planning', number: 'NSIP-CERT-2026-00015', score: 91, date: '2026-02-14' },
  ];

  return (
    <>
      {/* Centralised Module Status Bar */}
      <div style={{ display: 'flex', gap: '12px', marginBottom: '24px' }}>
        {[
          { label: 'Points Balance', value: points.toLocaleString(), icon: '⭐', color: '#f59e0b' },
          { label: 'Week Streak', value: `${weeklyStreak} wks 🔥`, icon: '', color: 'var(--neo-danger)' },
          { label: 'Monthly', value: `${monthlyStreaks} 🏆`, icon: '', color: 'var(--neo-accent)' },
          { label: 'Certificates', value: String(certs), icon: '📜', color: 'var(--neo-primary)' },
        ].map(m => <div key={m.label} style={{ flex: 1, padding: '16px', borderRadius: '12px', background: 'var(--neo-surface)', border: '1px solid var(--neo-border)', textAlign: 'center' }}><div style={{ fontSize: '0.75rem', color: 'var(--neo-text-muted)', marginBottom: '4px' }}>{m.icon} {m.label}</div><div style={{ fontSize: '1.5rem', fontWeight: 700, color: m.color }}>{m.value}</div></div>)}
      </div>

      {/* Tab Navigation */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '24px' }}>
        {(['dashboard', 'courses', 'session'] as const).map(t => <button key={t} onClick={() => setTab(t)} style={{ padding: '10px 20px', borderRadius: '100px', border: tab === t ? 'none' : '1px solid var(--neo-border)', background: tab === t ? 'var(--neo-primary)' : 'transparent', color: tab === t ? '#fff' : 'var(--neo-text-muted)', cursor: 'pointer', fontWeight: 600, textTransform: 'capitalize' }}>{t === 'session' ? '📅 Book Session' : t === 'courses' ? '📚 Course Catalog' : '📊 Dashboard'}</button>)}
      </div>

      {tab === 'dashboard' && <>
        {/* Streak & Progress */}
        <div className="neo-grid">
          <div className="neo-card">
            <h4 style={{ marginBottom: '16px' }}>🔥 Weekly Streak ({activeDaysThisWeek}/4 days this week)</h4>
            <div style={{ display: 'flex', gap: '6px', marginBottom: '16px' }}>{['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map((d, i) => <div key={d} style={{ flex: 1, textAlign: 'center' }}><div style={{ fontSize: '0.65rem', color: 'var(--neo-text-muted)', marginBottom: '4px' }}>{d}</div><div style={{ width: '32px', height: '32px', borderRadius: '8px', background: i < activeDaysThisWeek ? 'var(--neo-accent)' : 'var(--neo-surface-hover)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.7rem', color: i < activeDaysThisWeek ? '#fff' : 'var(--neo-text-muted)', margin: '0 auto' }}>{i < activeDaysThisWeek ? '✓' : ''}</div></div>)}</div>
            <div style={{ height: '6px', borderRadius: '3px', background: 'var(--neo-border)', marginBottom: '8px' }}><div style={{ height: '100%', borderRadius: '3px', background: activeDaysThisWeek >= 4 ? 'var(--neo-accent)' : '#f59e0b', width: `${(activeDaysThisWeek/4)*100}%` }} /></div>
            <p style={{ color: 'var(--neo-text-muted)', fontSize: '0.85rem' }}>{activeDaysThisWeek >= 4 ? '✅ Weekly streak achieved! +100 pts' : `${4 - activeDaysThisWeek} more day(s) needed for weekly streak`}</p>
            <div style={{ marginTop: '16px', padding: '12px', borderRadius: '8px', background: 'rgba(99,102,241,0.08)' }}>
              <div style={{ fontSize: '0.8rem', color: 'var(--neo-text-muted)', marginBottom: '4px' }}>Monthly Progress: {weeklyStreak}/4 weekly streaks</div>
              <div style={{ height: '6px', borderRadius: '3px', background: 'var(--neo-border)' }}><div style={{ height: '100%', borderRadius: '3px', background: 'var(--neo-stripe-purple)', width: `${(weeklyStreak/4)*100}%` }} /></div>
            </div>
            <div style={{ marginTop: '16px', fontSize: '0.8rem', color: 'var(--neo-text-muted)' }}>
              <div style={{ fontWeight: 600, marginBottom: '4px' }}>Qualifying activities:</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>{['BMC','EMF','Quiz','Lesson','Session','Event','Mini-Game','Planner'].map(a => <span key={a} className="neo-badge success" style={{ fontSize: '0.7rem' }}>{a}</span>)}</div>
            </div>
          </div>
          <div className="neo-card">
            <h4 style={{ marginBottom: '16px' }}>🏆 My Certificates</h4>
            {myCerts.map(c => <div key={c.number} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--neo-border)' }}><div><div style={{ fontWeight: 500 }}>{c.name}</div><div style={{ fontSize: '0.75rem', color: 'var(--neo-text-muted)' }}>{c.number}</div></div><span className="neo-badge success">{c.score}%</span></div>)}
          </div>
        </div>
        {/* Course Progress Overview */}
        <h4 style={{ margin: '24px 0 16px' }}>Course Progress</h4>
        <div className="neo-grid">
          {courses.map(c => <div key={c.id} className="neo-card"><div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}><h4>{c.title}</h4><span className="neo-badge success">{c.difficulty}</span></div><div style={{ height: '6px', borderRadius: '3px', background: 'var(--neo-border)', marginBottom: '8px' }}><div style={{ height: '100%', borderRadius: '3px', background: c.progress === 100 ? 'var(--neo-accent)' : 'var(--neo-primary)', width: `${c.progress}%`, transition: 'width 0.5s ease' }} /></div><div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', color: 'var(--neo-text-muted)' }}><span>{c.duration} min · {c.points} pts</span><span>{c.progress}%</span></div></div>)}
        </div>
      </>}

      {tab === 'courses' && <>
        <h3 style={{ marginBottom: '24px' }}>📚 Course Catalog</h3>
        {quizActive ? <div className="neo-card">
          <h4 style={{ marginBottom: '16px' }}>Quiz: Investment Fundamentals</h4>
          <p style={{ color: 'var(--neo-text-muted)', marginBottom: '16px' }}>Answer 10 questions. Score ≥70% to pass, ≥90% for certificate.</p>
          {[{ q: 'What is compound interest?', a: ['Interest on principal only', 'Interest on principal + accumulated interest', 'Fixed rate return'] }, { q: 'Which asset class is most volatile?', a: ['Bonds', 'Real Estate', 'Equities'] }, { q: 'What does ETF stand for?', a: ['Electronic Transfer Fund', 'Exchange-Traded Fund', 'Equity Trust Fund'] }].map((quiz, i) => <div key={i} style={{ marginBottom: '16px', padding: '16px', borderRadius: '12px', border: '1px solid var(--neo-border)' }}><div style={{ fontWeight: 500, marginBottom: '8px' }}>Q{i + 1}. {quiz.q}</div>{quiz.a.map((a, j) => <label key={j} style={{ display: 'block', padding: '8px 12px', borderRadius: '8px', cursor: 'pointer', marginBottom: '4px', background: 'var(--neo-surface-hover)' }}><input type="radio" name={`q${i}`} style={{ marginRight: '8px' }} />{a}</label>)}</div>)}
          <button className="neo-btn" onClick={() => { setQuizScore(85); setQuizActive(false); }}>Submit Quiz</button>
        </div> : <>
          {quizScore > 0 && <div style={{ background: 'rgba(16,185,129,0.1)', border: '1px solid var(--neo-accent)', borderRadius: '12px', padding: '16px', marginBottom: '24px', color: 'var(--neo-accent)' }}>✅ Quiz completed! Score: {quizScore}% — {quizScore >= 90 ? 'Certificate earned! 🏆' : 'Passed! Points awarded.'}</div>}
          <div className="neo-grid">
            {courses.map(c => <div key={c.id} className="neo-card"><div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px' }}><span className="neo-badge warning">{c.category}</span><span className="neo-badge success">{c.difficulty}</span></div><h4 style={{ marginBottom: '8px' }}>{c.title}</h4><p style={{ color: 'var(--neo-text-muted)', fontSize: '0.85rem', marginBottom: '16px' }}>{c.duration} min · {c.points} points · Quiz: 10 questions</p><div style={{ display: 'flex', gap: '8px' }}><button className="neo-btn outline" style={{ flex: 1 }}>▶ Watch Video</button><button className="neo-btn" style={{ flex: 1 }} onClick={() => setQuizActive(true)}>Take Quiz</button></div></div>)}
          </div>
        </>}
      </>}

      {tab === 'session' && <>
        <h3 style={{ marginBottom: '8px' }}>📅 Book Financial Advisor Session</h3>
        <p style={{ color: 'var(--neo-text-muted)', marginBottom: '24px' }}>1-on-1 session costs <strong>1,000 points</strong>. Points are <strong>restored on cancellation</strong>. Your balance: <strong style={{ color: points >= 1000 ? 'var(--neo-accent)' : 'var(--neo-danger)' }}>{points} pts</strong></p>
        <div className="neo-grid">
          {[{ name: 'Sarah Al-Rashid', specialty: 'Retirement Planning', rating: 4.9, reviews: 47, sessions: 120, slots: 3 }, { name: 'Ahmed Malik', specialty: 'Investment Strategy', rating: 4.8, reviews: 35, sessions: 89, slots: 1 }, { name: 'Fatima Hassan', specialty: 'Tax Optimization', rating: 4.7, reviews: 28, sessions: 64, slots: 5 }].map(a => <div key={a.name} className="neo-card"><div style={{ fontSize: '2.5rem', marginBottom: '12px' }}>👤</div><h4>{a.name}</h4><p style={{ color: 'var(--neo-text-muted)', fontSize: '0.85rem', marginBottom: '8px' }}>{a.specialty}</p><div style={{ display: 'flex', gap: '16px', marginBottom: '12px', fontSize: '0.8rem', color: 'var(--neo-text-muted)' }}><span>⭐ {a.rating} ({a.reviews} reviews)</span><span>📅 {a.sessions} sessions</span></div><div style={{ display: 'flex', gap: '4px', marginBottom: '16px' }}>{[1,2,3,4,5].map(s => <span key={s} style={{ color: s <= Math.round(a.rating) ? '#f59e0b' : 'var(--neo-border)', fontSize: '1.1rem' }}>★</span>)}</div><button className="neo-btn" disabled={points < 1000}>Book (1,000 pts)</button></div>)}
        </div>

        <h4 style={{ margin: '32px 0 16px' }}>My Bookings</h4>
        <div className="neo-card" style={{ padding: 0, overflow: 'hidden' }}><table className="neo-sheet"><thead><tr><th>Advisor</th><th>Date</th><th>Status</th><th>Action</th></tr></thead><tbody>
          <tr><td>Sarah Al-Rashid</td><td>May 5, 2026</td><td><span className="neo-badge success">Booked</span></td><td style={{ display: 'flex', gap: '8px' }}><button className="neo-btn outline" style={{ padding: '6px 12px', borderColor: 'var(--neo-danger)', color: 'var(--neo-danger)' }}>Cancel (+1000 pts)</button></td></tr>
          <tr><td>Ahmed Malik</td><td>Apr 20, 2026</td><td><span className="neo-badge success">Completed</span></td><td><button className="neo-btn outline" style={{ padding: '6px 12px' }}>★ Leave Review</button></td></tr>
        </tbody></table></div>

        <h4 style={{ margin: '32px 0 16px' }}>💳 Payment Gateway</h4>
        <div className="neo-card"><div style={{ display: 'flex', gap: '16px' }}>{['Stripe', 'Apple Pay', 'Mada (Local)'].map(g => <button key={g} className="neo-btn outline" style={{ flex: 1 }}>{g}</button>)}</div></div>

        <div className="neo-card" style={{ marginTop: '24px', background: 'rgba(99,102,241,0.05)', border: '1px solid var(--neo-stripe-purple)' }}>
          <h4 style={{ color: 'var(--neo-stripe-purple)', marginBottom: '8px' }}>📊 Point Economics</h4>
          <div style={{ color: 'var(--neo-text-muted)', fontSize: '0.85rem', lineHeight: '1.8' }}>
            <div>• Course completion: <strong>50-150 pts</strong> (1st attempt = 100%, 2nd = 50%, 3rd+ = 25%)</div>
            <div>• Quiz bonus: <strong>+1 pt per % above passing score</strong></div>
            <div>• 7-day streak: <strong>+100 pts</strong> · 14-day: <strong>+200 pts</strong> · 30-day: <strong>+500 pts</strong></div>
            <div>• Event attendance: <strong>+50 pts</strong></div>
            <div>• Session booking: <strong>-1,000 pts</strong> · Cancellation: <strong>+1,000 pts refund</strong></div>
          </div>
        </div>
      </>}
    </>
  );
}

// --- Planning Page ---
function PlanningPage() {
  const [income, setIncome] = useState('');
  const [expenses, setExpenses] = useState('');
  const incomeNum = Number(income) || 0;
  const expensesNum = Number(expenses) || 0;
  const savings = incomeNum - expensesNum;
  const emergencyGoal = expensesNum * 6;

  return (
    <>
      <h3 style={{ marginBottom: '24px' }}>Smartsheet Financial Planner</h3>
      <div className="neo-grid">
        <div className="neo-card">
          <h4 style={{ marginBottom: '16px' }}>Expense Calculator</h4>
          <input type="number" placeholder="Monthly Income (SAR)" value={income} onChange={e => setIncome(e.target.value)} min="0" style={{ width: '100%', padding: '10px', borderRadius: '8px', border: '1px solid var(--neo-border)', background: 'var(--neo-bg)', color: 'var(--neo-text)', marginBottom: '12px', boxSizing: 'border-box' }} />
          <input type="number" placeholder="Monthly Expenses (SAR)" value={expenses} onChange={e => setExpenses(e.target.value)} min="0" style={{ width: '100%', padding: '10px', borderRadius: '8px', border: '1px solid var(--neo-border)', background: 'var(--neo-bg)', color: 'var(--neo-text)', marginBottom: '12px', boxSizing: 'border-box' }} />
          <div style={{ padding: '16px', borderRadius: '12px', background: savings >= 0 ? 'rgba(34,197,94,0.08)' : 'rgba(239,68,68,0.08)' }}>
            <span style={{ color: 'var(--neo-text-muted)' }}>Remaining Savings</span>
            <div style={{ fontSize: '1.5rem', fontWeight: 700, color: savings >= 0 ? 'var(--neo-success)' : 'var(--neo-danger)' }}>SAR {savings.toLocaleString()}</div>
          </div>
        </div>
        <div className="neo-card">
          <h4 style={{ marginBottom: '16px' }}>Emergency Fund Planner</h4>
          <div style={{ padding: '16px', borderRadius: '12px', background: 'rgba(239,68,68,0.08)', marginBottom: '16px' }}>
            <span style={{ color: 'var(--neo-text-muted)' }}>6-Month Emergency Goal</span>
            <div style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--neo-danger)' }}>SAR {emergencyGoal.toLocaleString()}</div>
          </div>
          <div style={{ padding: '16px', borderRadius: '12px', background: 'rgba(59,130,246,0.08)' }}>
            <span style={{ color: 'var(--neo-text-muted)' }}>Personal Loan Eligibility (30%)</span>
            <div style={{ fontSize: '1.5rem', fontWeight: 700, color: '#3B82F6' }}>SAR 45,000</div>
          </div>
        </div>
      </div>
    </>
  );
}

// --- Help Centre Page ---
function HelpCentrePage() {
  const [channels, setChannels] = useState({
    whatsapp: true, email: true, sms: false, twitter: false, instagram: false
  });

  const toggle = (key: string) => setChannels(prev => ({ ...prev, [key]: !prev[key as keyof typeof prev] }));

  const channelList = [
    { key: 'whatsapp', label: 'WhatsApp Business', desc: 'Instant alerts on WhatsApp' },
    { key: 'email', label: 'Email Notification', desc: 'Detailed PDF receipts' },
    { key: 'sms', label: 'SMS Alerts', desc: 'Critical alerts via text' },
    { key: 'twitter', label: 'X (Twitter) DM', desc: 'Connect your X account' },
    { key: 'instagram', label: 'Instagram / Snapchat', desc: 'Social media alerts' },
  ];

  return (
    <div className="neo-card" style={{ maxWidth: '600px' }}>
      <h3 style={{ marginBottom: '8px' }}>Help Centre & Omni-Channel Support</h3>
      <p style={{ color: 'var(--neo-text-muted)', fontSize: '0.9rem', marginBottom: '32px' }}>Enable your preferred channels for support and claim notifications.</p>
      {channelList.map(ch => (
        <div key={ch.key} className="toggle-row" onClick={() => toggle(ch.key)} style={{ cursor: 'pointer' }}>
          <div><div style={{ fontWeight: '500' }}>{ch.label}</div><div style={{ fontSize: '0.8rem', color: 'var(--neo-text-muted)' }}>{ch.desc}</div></div>
          <div className={`toggle-switch ${channels[ch.key as keyof typeof channels] ? '' : 'off'}`}></div>
        </div>
      ))}
    </div>
  );
}

// --- Digital Wallet Page ---
function WalletPage() {
  return (
    <>
      <header className="neo-header"><div><div style={{ color: 'var(--neo-text-muted)', marginBottom: '8px' }}>Wallet Balance</div><div className="neo-balance">SAR 3,240<span style={{ fontSize: '1.5rem', color: 'var(--neo-text-muted)' }}>.50</span></div></div><div><button className="neo-btn">+ Top Up</button></div></header>
      <div className="neo-grid">
        <div className="neo-card"><div className="neo-card-label">Linked Bank</div><div className="neo-card-value">Al Rajhi ****4821</div><button className="neo-btn outline" style={{ marginTop: '16px' }}>Manage</button></div>
        <div className="neo-card"><div className="neo-card-label">Auto-Debit</div><div className="neo-card-value" style={{ color: 'var(--neo-accent)' }}>Active</div><p style={{ color: 'var(--neo-text-muted)', fontSize: '0.85rem', marginTop: '8px' }}>4% contribution auto-deducted on the 1st</p></div>
      </div>
      <h3 style={{ marginBottom: '16px' }}>Recent Transactions</h3>
      <div className="neo-card" style={{ padding: 0, overflow: 'hidden' }}>
        <table className="neo-sheet"><thead><tr><th>Date</th><th>Description</th><th>Amount</th><th>Status</th></tr></thead><tbody>
          <tr><td>30 Apr</td><td>Monthly Contribution</td><td style={{ color: 'var(--neo-danger)' }}>-SAR 480</td><td><span className="neo-badge success">Paid</span></td></tr>
          <tr><td>28 Apr</td><td>Loan Repayment Installment</td><td style={{ color: 'var(--neo-danger)' }}>-SAR 625</td><td><span className="neo-badge success">Paid</span></td></tr>
          <tr><td>25 Apr</td><td>Wallet Top-up (Stripe)</td><td style={{ color: 'var(--neo-accent)' }}>+SAR 5,000</td><td><span className="neo-badge success">Done</span></td></tr>
          <tr><td>15 Apr</td><td>Points Redemption Cashback</td><td style={{ color: 'var(--neo-accent)' }}>+SAR 100</td><td><span className="neo-badge success">Done</span></td></tr>
        </tbody></table>
      </div>
    </>
  );
}

// --- Wellness Page (Fitness + Chronic Care) ---
function WellnessPage() {
  const fitnessTips = [
    { icon: '🏃', title: '30-Min Daily Walk', desc: 'Reduces heart disease risk by 30%. Walk during lunch breaks for easy consistency.', tag: 'Cardio' },
    { icon: '🧘', title: 'Morning Stretch Routine', desc: '10-minute stretches reduce back pain for desk workers by 40%.', tag: 'Flexibility' },
    { icon: '💧', title: 'Hydration Goal', desc: 'Drink 8 glasses (2L) daily. Dehydration reduces productivity by 25%.', tag: 'Nutrition' },
    { icon: '😴', title: 'Sleep Hygiene', desc: '7-8 hours of sleep. No screens 1 hour before bed improves sleep quality.', tag: 'Recovery' },
  ];
  const chronicPrograms = [
    { icon: '💉', title: 'Diabetes Management', desc: 'Home glucose monitoring kit + monthly nurse visits. Covered under your insurance plan.', status: 'Enroll' },
    { icon: '❤️', title: 'Cardiac Rehabilitation', desc: 'At-home exercise program with remote cardiologist monitoring via wearable.', status: 'Enroll' },
    { icon: '🫁', title: 'Respiratory Care', desc: 'Nebulizer kit + pulmonologist teleconsults for asthma and COPD patients.', status: 'Active' },
    { icon: '🦴', title: 'Chronic Pain Support', desc: 'Physiotherapy home visits + pain management specialist teleconsults.', status: 'Enroll' },
  ];
  return (
    <>
      <h3 style={{ marginBottom: '24px' }}>🏃 Fitness Tips & Suggestions</h3>
      <div className="neo-grid">
        {fitnessTips.map(t => <div key={t.title} className="neo-card"><div style={{ fontSize: '2rem', marginBottom: '12px' }}>{t.icon}</div><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}><h4>{t.title}</h4><span className="neo-badge success">{t.tag}</span></div><p style={{ color: 'var(--neo-text-muted)', fontSize: '0.9rem' }}>{t.desc}</p></div>)}
      </div>
      <h3 style={{ margin: '32px 0 24px' }}>🏠 Home Assistance — Chronic Disease Programs</h3>
      <div className="neo-grid">
        {chronicPrograms.map(p => <div key={p.title} className="neo-card"><div style={{ fontSize: '2rem', marginBottom: '12px' }}>{p.icon}</div><h4 style={{ marginBottom: '8px' }}>{p.title}</h4><p style={{ color: 'var(--neo-text-muted)', fontSize: '0.9rem', marginBottom: '16px' }}>{p.desc}</p><button className={`neo-btn ${p.status === 'Active' ? 'stripe' : 'outline'}`}>{p.status === 'Active' ? '✓ Currently Active' : 'Enroll Now'}</button></div>)}
      </div>
    </>
  );
}

// =============================================================================
// Employer Portal (with Event Proposals)
// =============================================================================
function EmployerPortal() {
  const [dragActive, setDragActive] = useState(false);
  const [tab, setTab] = useState<'payroll'|'events'>('payroll');
  const [evtTitle, setEvtTitle] = useState(''); const [evtCat, setEvtCat] = useState('RAMADAN_EVENT');
  const [evtDesc, setEvtDesc] = useState(''); const [submitted, setSubmitted] = useState(false);
  const categories = ['RAMADAN_EVENT','CHARITY_RUN','ANNIVERSARY_MEETUP','SUCCESS_MEETUP','FINANCIAL_LITERACY','WELLNESS','TEAM_BUILDING','OTHER'];
  const myEvents = [{title:'Ramadan Iftar 2026',cat:'RAMADAN_EVENT',status:'L2_APPROVED'},{title:'Annual 5K Run',cat:'CHARITY_RUN',status:'LIVE'},{title:'Q1 Success Meetup',cat:'SUCCESS_MEETUP',status:'DRAFT'}];
  return (
    <div className="neo-app">
      <aside className="neo-sidebar">
        <div className="neo-brand"><span>NSIP</span><span style={{ color: 'var(--neo-text-muted)', fontSize: '1rem' }}>Business</span></div>
        <nav className="neo-nav"><div className={`neo-nav-item ${tab==='payroll'?'active':''}`} onClick={()=>setTab('payroll')}>🏢 Payroll Upload</div><div className={`neo-nav-item ${tab==='events'?'active':''}`} onClick={()=>setTab('events')}>🎉 Event Proposals</div></nav>
        <div style={{ marginTop: 'auto' }}><NavLink to="/" className="neo-btn outline" style={{ textDecoration: 'none', display: 'block', textAlign: 'center' }}>Log Out</NavLink></div>
      </aside>
      <main className="neo-main">
        {tab==='payroll' ? <>
          <header className="neo-header"><div><div style={{ color: 'var(--neo-text-muted)', marginBottom: '8px', fontWeight: '500' }}>Pending Contributions</div><div className="neo-balance">SAR 42,000<span style={{ fontSize: '1.5rem', color: 'var(--neo-text-muted)' }}>.00</span></div></div><div><button className="neo-btn">Pay via Gateway</button></div></header>
          <div className="neo-card"><h3 style={{ marginBottom: '16px' }}>Upload Monthly Payroll</h3><p style={{ color: 'var(--neo-text-muted)', marginBottom: '24px' }}>Upload your employees' salaries CSV to auto-calculate the 4% deduction.</p><div onDragOver={e=>{e.preventDefault();setDragActive(true)}} onDragLeave={()=>setDragActive(false)} onDrop={()=>setDragActive(false)} style={{ border: `2px dashed ${dragActive?'#3B82F6':'var(--neo-border)'}`, padding: '40px', textAlign: 'center', borderRadius: '12px', color: dragActive?'#3B82F6':'var(--neo-text-muted)', transition: 'all 0.2s ease' }}>{dragActive?'Drop your CSV file here':'Drag and drop your Payroll CSV here'}</div></div>
        </> : <>
          <h3 style={{ marginBottom: '24px' }}>Propose a New Event</h3>
          {submitted && <div style={{ background: 'rgba(16,185,129,0.1)', border: '1px solid var(--neo-accent)', borderRadius: '12px', padding: '16px', marginBottom: '24px', color: 'var(--neo-accent)' }}>✅ Event submitted for L1 review!</div>}
          <div className="neo-card" style={{ marginBottom: '32px' }}>
            <input placeholder="Event Title (e.g. Ramadan Iftar 2026)" value={evtTitle} onChange={e=>setEvtTitle(e.target.value)} style={{ width:'100%',padding:'10px',borderRadius:'8px',border:'1px solid var(--neo-border)',background:'var(--neo-bg)',color:'var(--neo-text)',marginBottom:'12px',boxSizing:'border-box' }} />
            <select value={evtCat} onChange={e=>setEvtCat(e.target.value)} style={{ width:'100%',padding:'10px',borderRadius:'8px',border:'1px solid var(--neo-border)',background:'var(--neo-bg)',color:'var(--neo-text)',marginBottom:'12px',boxSizing:'border-box' }}>{categories.map(c=><option key={c} value={c}>{c.replace(/_/g,' ')}</option>)}</select>
            <textarea placeholder="Description" value={evtDesc} onChange={e=>setEvtDesc(e.target.value)} rows={3} style={{ width:'100%',padding:'10px',borderRadius:'8px',border:'1px solid var(--neo-border)',background:'var(--neo-bg)',color:'var(--neo-text)',marginBottom:'12px',boxSizing:'border-box',resize:'vertical' }} />
            <button className="neo-btn" onClick={()=>{setSubmitted(true);setEvtTitle('');setEvtDesc('')}}>Submit for Approval</button>
          </div>
          <h3 style={{ marginBottom: '16px' }}>My Event Proposals</h3>
          <div className="neo-card" style={{ padding:0,overflow:'hidden' }}><table className="neo-sheet"><thead><tr><th>Event</th><th>Category</th><th>Approval Status</th></tr></thead><tbody>{myEvents.map(e=><tr key={e.title}><td>{e.title}</td><td>{e.cat.replace(/_/g,' ')}</td><td><span className={`neo-badge ${e.status==='LIVE'?'success':'warning'}`}>{e.status.replace(/_/g,' ')}</span></td></tr>)}</tbody></table></div>
        </>}
      </main>
    </div>
  );
}

// =============================================================================
// Admin Portal
// =============================================================================
function AdminPortal() {
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState<'claims'|'events'>('claims');
  const handleAction = async (claimId: string, action: 'approve' | 'reject') => { setLoading(true); try { if (action === 'approve') await api.approveClaim(claimId); else await api.rejectClaim(claimId); } catch {} finally { setLoading(false); } };
  const pendingEvents = [
    {title:'Company Anniversary Dinner',org:'AlFuttaim Group',status:'DRAFT',level:'L1'},
    {title:'Ramadan Charity Bazaar',org:'STC Telecom',status:'L1_APPROVED',level:'L2'},
    {title:'5K Health Run',org:'SABIC Industries',status:'L2_APPROVED',level:'L3'},
  ];
  return (
    <div className="neo-app">
      <aside className="neo-sidebar">
        <div className="neo-brand"><span>NSIP</span><span style={{ color: 'var(--neo-stripe-purple)', fontSize: '1rem' }}>Back Office</span></div>
        <nav className="neo-nav"><div className={`neo-nav-item ${tab==='claims'?'active':''}`} onClick={()=>setTab('claims')}>🛡️ Claim Approvals</div><div className={`neo-nav-item ${tab==='events'?'active':''}`} onClick={()=>setTab('events')}>🎉 Event Approvals</div></nav>
        <div style={{ marginTop: 'auto' }}><NavLink to="/" className="neo-btn outline" style={{ textDecoration: 'none', display: 'block', textAlign: 'center' }}>Log Out</NavLink></div>
      </aside>
      <main className="neo-main">
        {loading && <LoadingSpinner />}
        {tab==='claims' ? <>
          <header className="neo-header"><div><div className="neo-balance" style={{ fontSize: '2.5rem' }}>Pending Claims Queue</div></div></header>
          <div className="neo-card" style={{ padding: '0', overflow: 'hidden' }}><table className="neo-sheet"><thead><tr><th>Beneficiary ID</th><th>Claim Type</th><th>Amount</th><th>Vesting Status</th><th>Action</th></tr></thead><tbody>
            <tr><td>USR-1029</td><td>Personal Loan</td><td>SAR 15,000</td><td><span className="neo-badge success">Passed (5 Yrs)</span></td><td><button className="neo-btn" style={{ padding: '8px 16px' }} onClick={() => handleAction('claim-1', 'approve')}>Approve</button></td></tr>
            <tr><td>USR-4421</td><td>Emergency Relief</td><td>SAR 100,000</td><td><span className="neo-badge warning">Pending Docs</span></td><td><button className="neo-btn outline" style={{ padding: '8px 16px' }} onClick={() => handleAction('claim-2', 'reject')}>Review</button></td></tr>
          </tbody></table></div>
        </> : <>
          <header className="neo-header"><div><div className="neo-balance" style={{ fontSize: '2.5rem' }}>3-Layer Event Approvals</div></div></header>
          <div style={{ display:'flex', gap:'12px', marginBottom:'24px' }}>{['L1 Reviewer','L2 Manager','L3 Director'].map((l,i)=><div key={l} style={{ flex:1, padding:'16px', borderRadius:'12px', background:'var(--neo-surface)', border:'1px solid var(--neo-border)', textAlign:'center' }}><div style={{ fontSize:'0.8rem', color:'var(--neo-text-muted)', marginBottom:'4px' }}>{l}</div><div style={{ fontSize:'1.5rem', fontWeight:700 }}>{[1,1,1][i]}</div></div>)}</div>
          <div className="neo-card" style={{ padding:0, overflow:'hidden' }}><table className="neo-sheet"><thead><tr><th>Event Title</th><th>Organization</th><th>Current Stage</th><th>Awaiting</th><th>Action</th></tr></thead><tbody>
            {pendingEvents.map(e=><tr key={e.title}><td>{e.title}</td><td>{e.org}</td><td><span className="neo-badge warning">{e.status.replace(/_/g,' ')}</span></td><td>{e.level} Review</td><td style={{ display:'flex', gap:'8px' }}><button className="neo-btn" style={{ padding:'8px 16px' }}>Approve</button><button className="neo-btn outline" style={{ padding:'8px 16px', borderColor:'var(--neo-danger)', color:'var(--neo-danger)' }}>Reject</button></td></tr>)}
          </tbody></table></div>
        </>}
      </main>
    </div>
  );
}

// =============================================================================
// App Root with Router
// =============================================================================
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<RoleSelector />} />
        <Route path="/customer/*" element={<CustomerPortal />} />
        <Route path="/employer" element={<EmployerPortal />} />
        <Route path="/admin" element={<AdminPortal />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
