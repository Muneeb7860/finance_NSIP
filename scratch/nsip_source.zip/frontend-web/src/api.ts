/**
 * API Service Layer — centralizes all backend calls.
 * FLAW #23 FIX: Replaces hardcoded data with real API calls.
 */

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8081';

async function request(path: string, options?: RequestInit) {
  const token = localStorage.getItem('nsip_token');
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const response = await fetch(`${API_BASE}${path}`, { ...options, headers });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Network error' }));
    throw new Error(error.error || `HTTP ${response.status}`);
  }

  return response.json();
}

export const api = {
  // Auth
  login: (email: string, password: string) =>
    request('/api/v1/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),

  register: (data: { nationalId: string; fullName: string; email: string; password: string; role: string }) =>
    request('/api/v1/auth/register', { method: 'POST', body: JSON.stringify(data) }),

  // Claims
  submitClaim: (userId: string, claimType: string, amount: string, description: string) =>
    request('/api/v1/claims', { method: 'POST', body: JSON.stringify({ userId, claimType, amount, description }) }),

  getUserClaims: (userId: string) => request(`/api/v1/claims/user/${userId}`),
  getPendingClaims: () => request('/api/v1/claims/pending'),
  approveClaim: (claimId: string) => request(`/api/v1/claims/${claimId}/approve`, { method: 'PATCH' }),
  rejectClaim: (claimId: string) => request(`/api/v1/claims/${claimId}/reject`, { method: 'PATCH' }),

  // Rewards
  getPointsBalance: (userId: string) => request(`/api/v1/rewards/balance/${userId}`),

  // Reviews
  submitReview: (userId: string, featureName: string, rating: number, comment: string) =>
    request('/api/v1/reviews', { method: 'POST', body: JSON.stringify({ userId, featureName, rating: String(rating), comment }) }),

  // Payments
  getUserRepayments: (userId: string) => request(`/api/v1/payments/repayments/${userId}`),
};
