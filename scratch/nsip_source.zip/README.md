# National Social Insurance Platform (NSIP)

A production-ready, event-driven microservices platform for national social insurance management.

## 🚀 Quick Start (Local)

To run the entire platform (10 microservices + Frontend + Infrastructure) locally, ensure you have **Docker** and **Node.js** installed, then run:

```bash
./run-locally.sh
```

This script will:
1. Build the React frontend.
2. Build all 10 Java microservices (Gradle multi-stage Docker builds).
3. Start Postgres, Kafka, Zookeeper, and Redis.
4. Launch all services in the background.

## 🌐 Access Points

| Component | URL |
|-----------|-----|
| **Contributor Portal** | [http://localhost:5173](http://localhost:5173) |
| **API Gateway** | [http://localhost:8080](http://localhost:8080) |
| **Swagger Docs** | [http://localhost:8080/swagger-ui.html](http://localhost:8080/swagger-ui.html) |

## 🛠 Tech Stack

- **Backend**: Java 17, Spring Boot 3, Spring Cloud Gateway
- **Frontend**: React (Web), Flutter (Mobile)
- **Database**: PostgreSQL (Service-per-DB pattern)
- **Messaging**: Apache Kafka (Event-driven architecture)
- **Cache**: Redis
- **Resilience**: Resilience4j (Circuit Breaker, Retry)
- **Orchestration**: Saga Pattern (persistent state)

## 📂 Project Structure

- `/backend`: 10 microservices, Docker Compose, and infrastructure configs.
- `/frontend-web`: React-based Contributor and Employer portal.
- `/frontend-mobile`: Flutter application for Contributors.
- `/docs`: BRD, PRD, HLD, and LLD documentation.
- `/k8s`: Kubernetes manifests for production deployment.

## 📋 Monitoring & Logs

To view logs for all services:
```bash
cd backend
docker-compose logs -f
```

To stop everything:
```bash
cd backend
docker-compose down
```
